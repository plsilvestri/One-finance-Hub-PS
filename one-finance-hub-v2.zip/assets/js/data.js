window.APP_DATA = {
  nav: [
    {id:'home',label:'Home',icon:'⌂'}, {id:'revenues',label:'Ricavi',icon:'▥'},
    {id:'projects',label:'Projects',icon:'🚆'}, {id:'executive',label:'Executive',icon:'⌁'},
    {id:'about',label:'Info',icon:'ⓘ'}
  ],
  kpis: [
    {name:'Revenue',value:'496,7 B¥',delta:'+6,1% vs Budget',tone:'positive',icon:'↗',go:'revenues'},
    {name:'EBAx',value:'48,2 B¥',delta:'+23,7% vs Budget',tone:'positive',icon:'◎',go:'railcontrol'},
    {name:'Orders',value:'462,6 B¥',delta:'+62,4% vs Budget',tone:'positive',icon:'◇',go:'railcontrol'},
    {name:'Backlog',value:'3.074,9 B¥',delta:'+13,6% vs Budget',tone:'positive',icon:'▤',go:'railcontrol'}
  ],
  areas: [
    {name:'Revenue Performance',desc:'Actual vs Budget',icon:'📊',go:'revenues'},
    {name:'Project Controlling',desc:'Portfolio dimostrativo',icon:'🚆',go:'projects'},
    {name:'Executive Cockpit',desc:'Insight sintetici',icon:'⌁',go:'executive'},
    {name:'Sicurezza mockup',desc:'Architettura e uso',icon:'🛡️',go:'about'}
  ],
  alerts:['3 progetti demo con margine sotto soglia','APAC EBAx sotto Budget','Cash conversion Europe sotto target'],
  lobs:[
    {name:'Vehicles',actual:188.8,budget:183.2,color:'#143d68'},
    {name:'Rail Control',actual:136.9,budget:131.8,color:'#3f86ce',go:'railcontrol'},
    {name:'Digital',actual:5.5,budget:0,color:'#8ea7cf'},
    {name:'GTS',actual:165.5,budget:153.3,color:'#626973'}
  ],
  markets:[['North America','47,5','+0,1%'],['EMEA','146,2','+10,0%'],['Americas','12,1','-41,0%'],['Italy','151,9','+5,3%'],['UK','85,0','+28,8%'],['Japan','0,0','-80,3%'],['Asia','53,9','-5,4%']],
  metrics:{
    month:[['Orders','462,6','+62,4%'],['Gross Margin','67,6','+18,6%'],['EBAx','48,2','+23,7%'],['Backlog','3.074,9','+13,6%'],['Invoices','299,5','+19,9%']],
    fy:[['Orders','961,0','+13,2%'],['Revenues','796,5','+7,2%'],['Gross Margin','177,0','+9,2%'],['EBAx','131,6','+13,5%'],['Invoices','780,4','-2,2%']]
  },
  projects:[['🔴','Project Alpha','Margine 1,8% · valore dimostrativo'],['🟠','Project Beta','CTC sopra piano · valore dimostrativo'],['🟡','Project Gamma','Milestone da monitorare · valore dimostrativo']],
  insights:[['📈','Growth','Revenue sopra Budget del 6,1%.'],['⚠️','Margin focus','Tre casi dimostrativi richiedono attenzione.'],['💧','Cash','Conversion da monitorare in Europe.'],['🌍','Markets','EMEA e UK guidano la crescita.'],['🧭','Outlook','Scenario demo complessivamente positivo.'],['🛡️','Data safety','Nessuna connessione a dati reali.']]
};