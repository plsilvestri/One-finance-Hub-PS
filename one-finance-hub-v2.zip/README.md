# One Finance Hub V2

Mockup statico e responsive, pronto per GitHub Pages.

## Caratteristiche
- HTML/CSS/JavaScript puro, senza dipendenze.
- Nessuna API, autenticazione, cookie, telemetria o database.
- Dati dimostrativi centralizzati in `assets/js/data.js`.
- Navigazione responsive desktop/mobile, ricerca locale e viste KPI.
- Banner permanente che identifica il progetto come demo pubblica.

## Pubblicazione su GitHub Pages
1. Crea un nuovo repository GitHub, ad esempio `one-finance-hub-v2`.
2. Estrai questo ZIP e carica **il contenuto della cartella**, mantenendo `index.html` nella root.
3. In GitHub apri **Settings → Pages**.
4. In **Build and deployment**, scegli **Deploy from a branch**.
5. Seleziona il branch `main` e la cartella `/ (root)`, quindi salva.
6. Il sito sarà disponibile all'indirizzo mostrato da GitHub Pages.

In alternativa, da terminale:

```bash
git init
git add .
git commit -m "Publish One Finance Hub V2 demo"
git branch -M main
git remote add origin https://github.com/TUO-UTENTE/one-finance-hub-v2.git
git push -u origin main
```

## Personalizzazione
- Testi e dati: `assets/js/data.js`
- Colori e layout: `assets/css/styles.css`
- Struttura e disclaimer: `index.html`

## Sicurezza
Questo repository è adatto solo a dati sintetici e a una demo pubblica. Non inserire dati aziendali, personali, credenziali, token, URL interni o segreti. Per un'applicazione reale usare hosting, identità, autorizzazioni e data governance approvati dall'organizzazione.

## Licenza
Puoi modificare questo mockup per uso personale o interno autorizzato. Verifica separatamente eventuali nomi, marchi e policy aziendali prima della pubblicazione.
